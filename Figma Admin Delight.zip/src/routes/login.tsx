import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Eye, EyeOff } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { GoogleSignInButton } from "@/components/GoogleSignInButton";
import { ensureSuperAdmin } from "@/lib/admin-bootstrap.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login — EduBari" },
      { name: "description", content: "Sign in to your EduBari account." },
    ],
  }),
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: typeof search.redirect === "string" ? search.redirect : undefined,
  }),
  component: LoginPage,
});

const schema = z.object({
  email: z.string().email("Enter a valid email address."),
  password: z.string().min(6, "Password must be at least 6 characters."),
  remember: z.boolean(),
});

type FormValues = z.infer<typeof schema>;

function LoginPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [show, setShow] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", password: "", remember: true },
  });

  const remember = watch("remember");

  const onSubmit = async (values: FormValues) => {
    const isSuperAdminEmail = values.email.trim().toLowerCase() === "contact@edubari.bd";
    if (isSuperAdminEmail) ensureSuperAdmin().catch(() => {});

    const { error } = await signIn(values.email, values.password);
    if (error) {
      toast.error(error);
      return;
    }
    if (!values.remember) {
      window.addEventListener("beforeunload", () => supabase.auth.signOut());
    }
    toast.success("Welcome back!");

    const { data: u } = await supabase.auth.getUser();
    let dest: string = "/dashboard";
    if (u.user) {
      const { data: rs } = await supabase.from("user_roles").select("role").eq("user_id", u.user.id);
      const roles = (rs ?? []).map((r) => r.role);
      if (roles.includes("admin") || roles.includes("super_admin")) dest = "/admin";
      supabase
        .from("activity_logs")
        .insert({ user_id: u.user.id, event: "login", metadata: { remember: values.remember } })
        .then(() => {});
    }
    // Honor ?redirect=... when present (e.g. user landed here from a guarded route)
    const finalDest = search.redirect && search.redirect.startsWith("/") ? search.redirect : dest;
    navigate({ to: finalDest });
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="container mx-auto px-6 py-16">
        <div className="mx-auto max-w-md rounded-2xl border border-border/50 bg-gradient-card p-8 shadow-card backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-500">
          <h1 className="font-display text-3xl font-bold">Welcome back</h1>
          <p className="mt-2 text-sm text-muted-foreground">Login to continue exploring premium books.</p>
          <form className="mt-6 space-y-4" onSubmit={handleSubmit(onSubmit)} noValidate>
            <div>
              <label className="text-sm text-muted-foreground">Email</label>
              <Input
                type="email"
                {...register("email")}
                placeholder="you@example.com"
                className="mt-1"
                autoComplete="username"
                aria-invalid={!!errors.email}
              />
              {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email.message}</p>}
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Password</label>
              <div className="relative mt-1">
                <Input
                  type={show ? "text" : "password"}
                  {...register("password")}
                  placeholder="••••••••"
                  className="pr-10"
                  autoComplete="current-password"
                  aria-invalid={!!errors.password}
                />
                <button
                  type="button"
                  onClick={() => setShow((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={show ? "Hide password" : "Show password"}
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && <p className="mt-1 text-xs text-destructive">{errors.password.message}</p>}
            </div>
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm text-muted-foreground">
                <Checkbox
                  checked={remember}
                  onCheckedChange={(v) => setValue("remember", Boolean(v))}
                />
                Remember me
              </label>
              <Link to="/forgot-password" className="text-sm text-primary hover:underline">Forgot password?</Link>
            </div>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="h-11 w-full rounded-lg bg-gradient-primary font-medium text-primary-foreground shadow-glow transition-all hover:opacity-95 hover:scale-[1.01]"
            >
              {isSubmitting ? "Signing in..." : "Login"}
            </Button>
          </form>
          <div className="my-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-border/50" />
            <span className="text-xs uppercase tracking-wider text-muted-foreground">or</span>
            <div className="h-px flex-1 bg-border/50" />
          </div>
          <GoogleSignInButton label="Sign in with Google" />
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link to="/signup" className="text-primary hover:underline">Sign up</Link>
            {" · "}
            <Link to="/admin-signup" className="text-primary hover:underline">Admin signup</Link>
          </p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
